"""
Devoir - Base de données & Data Science (ENCG Settat)
Sujet : pourquoi le chômage est-il si élevé au Maroc ?

Ce script :
1. importe le dataset (chomage_maroc.csv, données du HCP)
2. calcule quelques indicateurs
3. génère un graphique (graphique_chomage.png)

Utilisation : python script.py
Librairies  : pip install pandas matplotlib
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

# 1. Importation des données (le CSV doit être dans le même dossier)
dossier = Path(__file__).parent
df = pd.read_csv(dossier / "chomage_maroc.csv")

print("Aperçu du dataset :")
print(df.drop(columns="source").to_string(index=False))

# 2. Indicateurs
moy_avant = df.loc[df["annee"] <= 2019, "taux_national"].mean()
moy_apres = df.loc[df["annee"] >= 2020, "taux_national"].mean()
t2019 = df.loc[df["annee"] == 2019, "taux_national"].iloc[0]
t2024 = df.loc[df["annee"] == 2024, "taux_national"].iloc[0]

print(f"\nTaux moyen 2016-2019 : {moy_avant:.2f} %")
print(f"Taux moyen 2020-2025 : {moy_apres:.2f} %")
print(f"Évolution 2019 -> 2024 : {t2019} % -> {t2024} % ({t2024 - t2019:+.1f} points)")

# 3. Graphique : taux de chômage national, urbain et rural
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.plot(df["annee"], df["taux_national"], marker="o", linewidth=2.5,
        color="#1f4e9c", label="National")
ax.plot(df["annee"], df["taux_urbain"], marker="s", linewidth=1.8,
        color="#c0392b", label="Milieu urbain")
ax.plot(df["annee"], df["taux_rural"], marker="^", linewidth=1.8,
        color="#2e8b57", label="Milieu rural")
ax.axvspan(2019.5, 2020.5, color="grey", alpha=0.15)
ax.annotate("Covid-19", (2020, 2.2), ha="center", fontsize=9, color="dimgrey")
for x, y in zip(df["annee"], df["taux_national"]):
    ax.annotate(f"{y:.1f}", (x, y), textcoords="offset points",
                xytext=(0, 7), ha="center", fontsize=8, color="#1f4e9c")
ax.set_title("Taux de chômage au Maroc, 2016-2025 (en %)")
ax.set_xlabel("Année")
ax.set_ylabel("Taux de chômage (%)")
ax.set_xticks(df["annee"])
ax.set_ylim(0, 20)
ax.grid(axis="y", alpha=0.3)
ax.spines[["top", "right"]].set_visible(False)
ax.legend(loc="center right")
fig.text(0.01, 0.005, "Source : HCP, Activité, emploi et chômage (résultats annuels).",
         fontsize=7, color="dimgrey")
fig.tight_layout(rect=(0, 0.02, 1, 1))
fig.savefig(dossier / "graphique_chomage.png", dpi=200)
print("\nGraphique enregistré : graphique_chomage.png")
plt.show()
